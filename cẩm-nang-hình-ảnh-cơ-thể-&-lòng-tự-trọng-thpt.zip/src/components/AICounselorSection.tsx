import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  Loader2,
  Bot,
  User,
  HeartHandshake,
  Lightbulb,
  ShieldAlert,
  RotateCcw,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

const QUICK_PROMPTS = [
  'Làm sao để bớt xấu hổ khi bị bạn bè trêu chọc về vóc dáng?',
  'Mỗi lần lướt mạng xã hội mình đều thấy tự ti, phải làm sao?',
  'Làm thế nào để đặt ranh giới khi người thân hay bình phẩm ngoại hình?',
  'Mình muốn học cách yêu cơ thể nhưng khó quá, hãy cho mình lời khuyên.',
];

export const AICounselorSection: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: 'Chào bạn! Mình là Chuyên viên Tâm lý Học đường AI. Mình ở đây để lắng nghe mọi nỗi niềm, băn khoăn về ngoại hình, cảm xúc hay những lúc bạn bị trêu chọc. Đừng ngần ngại chia sẻ nhé, đây là không gian hoàn toàn an toàn và tôn trọng bạn!',
      timestamp: 'Vừa xong',
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async (questionText?: string) => {
    const textToSend = questionText || input;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!questionText) setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/ai/counselor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: textToSend }),
      });
      const data = await res.json();

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: data.advice || 'Xin lỗi bạn, hiện tại mình chưa thể xử lý câu trả lời này. Bạn thử lại nhé!',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'ai',
          text: 'Rất tiếc, đã có sự cố kết nối. Bạn hãy kiểm tra lại kết nối mạng hoặc thử lại sau giây lát nhé!',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    setMessages([
      {
        id: 'welcome',
        sender: 'ai',
        text: 'Chào bạn! Mình là Chuyên viên Tâm lý Học đường AI. Mình luôn sẵn sàng lắng nghe bạn!',
        timestamp: 'Vừa xong',
      },
    ]);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-800 to-slate-900 text-white p-5 sm:p-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white">Chuyên Gia Tâm Lý AI Đồng Hành</h2>
              <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> Sẵn sàng lắng nghe
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Tư vấn tâm lý, xoa dịu lo âu và hướng dẫn kỹ năng đối đáp dành riêng cho học sinh THPT
            </p>
          </div>
        </div>
        <button
          onClick={handleClear}
          title="Bắt đầu cuộc trò chuyện mới"
          className="text-slate-300 hover:text-white p-2 rounded-lg hover:bg-white/10 text-xs flex items-center gap-1 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
          <span className="hidden sm:inline">Làm mới</span>
        </button>
      </div>

      {/* Quick Prompts */}
      <div className="bg-slate-50 px-5 py-3 border-b border-slate-200/80">
        <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Lightbulb className="w-3.5 h-3.5 text-amber-500" /> Các câu hỏi bạn bè thường tâm sự:
        </div>
        <div className="flex flex-wrap gap-2">
          {QUICK_PROMPTS.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(prompt)}
              disabled={isLoading}
              className="text-left text-xs bg-white hover:bg-teal-50 hover:border-teal-300 border border-slate-200 text-slate-700 px-3 py-1.5 rounded-xl transition-all shadow-2xs"
            >
              "{prompt}"
            </button>
          ))}
        </div>
      </div>

      {/* Messages List */}
      <div className="p-5 sm:p-6 space-y-4 max-h-[460px] overflow-y-auto">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.sender === 'ai' && (
              <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Bot className="w-4 h-4" />
              </div>
            )}
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed whitespace-pre-line ${
                msg.sender === 'user'
                  ? 'bg-teal-700 text-white rounded-br-xs'
                  : 'bg-slate-100 text-slate-800 rounded-bl-xs border border-slate-200/60'
              }`}
            >
              {msg.text}
              <div
                className={`text-[10px] mt-1.5 ${
                  msg.sender === 'user' ? 'text-teal-200 text-right' : 'text-slate-400 text-left'
                }`}
              >
                {msg.timestamp}
              </div>
            </div>
            {msg.sender === 'user' && (
              <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-700 flex items-center justify-center flex-shrink-0 mt-0.5">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-3 items-center text-xs text-slate-500 italic py-2">
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center flex-shrink-0">
              <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
            </div>
            <span>Chuyên viên tâm lý AI đang lắng nghe và suy ngẫm lời khuyên phù hợp nhất cho bạn...</span>
          </div>
        )}
      </div>

      {/* Input Box */}
      <div className="p-4 sm:p-5 border-t border-slate-200 bg-white">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLoading}
            placeholder="Nhập điều bạn đang trăn trở, băn khoăn hay trải nghiệm vừa qua..."
            className="flex-1 px-4 py-3 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 bg-slate-50/50"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="px-5 py-3 rounded-xl bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            <span className="hidden sm:inline">Gửi tâm sự</span>
          </button>
        </form>

        <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 px-1">
          <span className="flex items-center gap-1">
            <HeartHandshake className="w-3.5 h-3.5 text-teal-600" /> Luôn đồng hành, thấu cảm và không phán xét
          </span>
          <span className="flex items-center gap-1">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-500" /> Trường hợp khẩn cấp liên hệ: 111 (24/7)
          </span>
        </div>
      </div>
    </div>
  );
};
