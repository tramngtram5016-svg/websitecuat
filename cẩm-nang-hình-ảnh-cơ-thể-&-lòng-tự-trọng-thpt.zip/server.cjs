var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json());
var aiClient = null;
function getAIClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!aiClient) {
    aiClient = new import_genai.GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return aiClient;
}
var PSYCHOLOGIST_SYSTEM_INSTRUCTION = `B\u1EA1n l\xE0 Chuy\xEAn gia T\xE2m l\xFD H\u1ECDc \u0111\u01B0\u1EDDng AI thu\u1ED9c \u1EE9ng d\u1EE5ng "C\u1EA9m Nang H\xECnh \u1EA2nh C\u01A1 Th\u1EC3 & L\xF2ng T\u1EF1 Tr\u1ECDng" d\xE0nh cho h\u1ECDc sinh THPT (t\u1EEB 15-18 tu\u1ED5i).
Phong c\xE1ch c\u1EE7a b\u1EA1n:
- Th\u1EA5u c\u1EA3m s\xE2u s\u1EAFc, \u1EA5m \xE1p, bao dung v\xE0 t\xF4n tr\u1ECDng tuy\u1EC7t \u0111\u1ED1i c\u1EA3m x\xFAc c\u1EE7a h\u1ECDc sinh.
- Ng\xF4n ng\u1EEF t\u1EF1 nhi\xEAn, hi\u1EC7n \u0111\u1EA1i, g\u1EA7n g\u0169i v\u1EDBi l\u1EE9a tu\u1ED5i h\u1ECDc tr\xF2 (c\xF3 th\u1EC3 x\u01B0ng "Th\u1EA7y/C\xF4/Chuy\xEAn gia" ho\u1EB7c "M\xECnh" v\xE0 g\u1ECDi ng\u01B0\u1EDDi h\u1ECFi l\xE0 "B\u1EA1n/Em").
- Tuy\u1EC7t \u0111\u1ED1i kh\xF4ng ph\xE1n x\xE9t, kh\xF4ng \u0111\u01B0a ra l\u1EDDi khuy\xEAn s\xE1o r\u1ED7ng ho\u1EB7c khuy\xEAn can h\u1EDDi h\u1EE3t ki\u1EC3u "h\xE3y c\u1ED1 l\xEAn", "\u0111\u1EEBng ngh\u0129 th\u1EBF n\u1EEFa".
- Lu\xF4n d\u1EF1a tr\xEAn c\xE1c n\u1EC1n t\u1EA3ng khoa h\u1ECDc t\xE2m l\xFD:
  1. Body Neutrality (T\xEDnh trung dung c\u01A1 th\u1EC3): C\u01A1 th\u1EC3 l\xE0 ng\xF4i nh\xE0 qu\xFD gi\xE1 gi\xFAp ta h\u1ECDc t\u1EADp, vui ch\u01A1i, th\u1EDF v\xE0 s\u1ED1ng \u2014 kh\xF4ng ph\u1EA3i m\xF3n h\xE0ng trang tr\xED \u0111\u1EC3 ng\u01B0\u1EDDi kh\xE1c \u0111\u1ECBnh gi\xE1.
  2. L\xF2ng t\u1EF1 tr\u1ECDng \u0111a di\u1EC7n: Ngo\u1EA1i h\xECnh ch\u1EC9 l\xE0 m\u1ED9t ph\u1EA7n r\u1EA5t nh\u1ECF. Gi\xE1 tr\u1ECB con ng\u01B0\u1EDDi \u0111\u01B0\u1EE3c b\u1ED3i \u0111\u1EAFp b\u1EDFi tr\xED tu\u1EC7, l\xF2ng nh\xE2n h\u1EADu, s\u1EF1 n\u1ED7 l\u1EF1c v\xE0 c\xE1ch ta \u0111\u1ED1i x\u1EED v\u1EDBi xung quanh.
  3. K\u1EF9 n\u0103ng \u1EE9ng ph\xF3 b\xECnh ph\u1EA9m: Gi\u1EEF b\xECnh t\u0129nh, \u0111\u1EB7t ranh gi\u1EDBi quy\u1EBFt \u0111o\xE1n (Assertive) ho\u1EB7c chuy\u1EC3n h\u01B0\u1EDBng kh\xE9o l\xE9o; kh\xF4ng c\xF4ng k\xEDch th\xF9 \u0111\u1ECBch v\xE0 c\u0169ng kh\xF4ng im l\u1EB7ng cam ch\u1ECBu.
- N\u1EBFu ng\u01B0\u1EDDi d\xF9ng chia s\u1EBB nh\u1EEFng d\u1EA5u hi\u1EC7u nguy hi\u1EC3m (t\u1EF1 h\u1EA1i, tr\u1EA7m c\u1EA3m n\u1EB7ng, bi quan c\u1EF1c \u0111\u1ED9), h\xE3y d\u1ECBu d\xE0ng khuy\xEAn em li\xEAn h\u1EC7 ng\u01B0\u1EDDi l\u1EDBn \u0111\xE1ng tin c\u1EADy ho\u1EB7c T\u1ED5ng \u0111\xE0i Qu\u1ED1c gia B\u1EA3o v\u1EC7 Tr\u1EBB em 111 (mi\u1EC5n c\u01B0\u1EDBc 24/7).`;
app.post("/api/ai/counselor", async (req, res) => {
  try {
    const { question, context } = req.body;
    if (!question || typeof question !== "string") {
      return res.status(400).json({ error: "C\xE2u h\u1ECFi kh\xF4ng h\u1EE3p l\u1EC7" });
    }
    const ai = getAIClient();
    if (!ai) {
      return res.json({
        advice: `C\u1EA3m \u01A1n b\u1EA1n \u0111\xE3 t\xE2m s\u1EF1 c\xF9ng chuy\xEAn gia t\xE2m l\xFD. V\u1EC1 v\u1EA5n \u0111\u1EC1 "${question}": H\xE3y nh\u1EDB r\u1EB1ng c\u01A1 th\u1EC3 c\u1EE7a b\u1EA1n \u0111ang trong giai \u0111o\u1EA1n ph\xE1t tri\u1EC3n tu\u1ED5i d\u1EADy th\xEC v\u1EDBi nhi\u1EC1u thay \u0111\u1ED5i t\u1EF1 nhi\xEAn. M\u1ECDi l\u1EDDi ch\xEA bai t\u1EEB ng\u01B0\u1EDDi kh\xE1c ph\u1EA3n \xE1nh s\u1EF1 thi\u1EBFu t\u1EBF nh\u1ECB c\u1EE7a h\u1ECD, kh\xF4ng \u0111\u1ECBnh ngh\u0129a gi\xE1 tr\u1ECB con ng\u01B0\u1EDDi b\u1EA1n. H\xE3y h\xEDt th\u1EDF s\xE2u, t\u1EADp trung v\xE0o nh\u1EEFng \u0111i\u1EC1u b\u1EA1n l\xE0m t\u1ED1t v\xE0 bao dung h\u01A1n v\u1EDBi ch\xEDnh m\xECnh b\u1EA1n nh\xE9!`,
        source: "fallback"
      });
    }
    const prompt = `H\u1ECDc sinh THPT g\u1EEDi c\xE2u h\u1ECFi / n\u1ED7i ni\u1EC1m:
"${question}"
${context ? `B\u1ED1i c\u1EA3nh ph\u1EE5 tr\u1EE3: ${context}` : ""}

H\xE3y \u0111\u01B0a ra l\u1EDDi khuy\xEAn t\xE2m l\xFD ch\xE2n th\xE0nh, chi ti\u1EBFt v\xE0 th\u1EF1c t\u1EBF (chia th\xE0nh 3 ph\u1EA7n ng\u1EAFn g\u1ECDn: 1. Th\u1EA5u c\u1EA3m & \u0110\xF3n nh\u1EADn c\u1EA3m x\xFAc; 2. Gi\u1EA3i m\xE3 t\xE2m l\xFD; 3. L\u1EDDi khuy\xEAn & H\xE0nh \u0111\u1ED9ng c\u1EE5 th\u1EC3 em c\xF3 th\u1EC3 l\xE0m ngay).`;
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: PSYCHOLOGIST_SYSTEM_INSTRUCTION,
        temperature: 0.7
      }
    });
    res.json({ advice: response.text || "Hi\u1EC7n t\u1EA1i chuy\xEAn gia ch\u01B0a ph\u1EA3n h\u1ED3i \u0111\u01B0\u1EE3c, b\u1EA1n th\u1EED l\u1EA1i nh\xE9!" });
  } catch (error) {
    console.error("AI Counselor Error:", error);
    res.status(500).json({
      error: "Kh\xF4ng th\u1EC3 k\u1EBFt n\u1ED1i v\u1EDBi chuy\xEAn gia AI l\xFAc n\xE0y.",
      details: error?.message
    });
  }
});
app.post("/api/ai/reframe", async (req, res) => {
  try {
    const { thought } = req.body;
    if (!thought || typeof thought !== "string") {
      return res.status(400).json({ error: "Suy ngh\u0129 kh\xF4ng h\u1EE3p l\u1EC7" });
    }
    const ai = getAIClient();
    if (!ai) {
      return res.json({
        trap: "B\u1EABy suy ngh\u0129 t\u1EF1 ph\xE1n x\xE9t & Ph\xF3ng \u0111\u1EA1i khuy\u1EBFt \u0111i\u1EC3m (Spotlight Effect)",
        truth: `Ngo\u1EA1i h\xECnh ch\u1EC9 l\xE0 m\u1ED9t ph\u1EA7n r\u1EA5t nh\u1ECF trong con ng\u01B0\u1EDDi b\u1EA1n. Suy ngh\u0129 "${thought}" l\xE0 c\u1EA3m x\xFAc t\u1EE9c th\u1EDDi, kh\xF4ng ph\u1EA3i l\xE0 s\u1EF1 th\u1EADt v\u1EC1 gi\xE1 tr\u1ECB b\u1EA3n th\xE2n. B\u1EA1n v\u1EABn c\xF3 nhi\u1EC1u t\xE0i n\u0103ng, ph\u1EA9m ch\u1EA5t t\u1ED1t \u0111\u1EB9p m\xE0 b\u1EA1n b\xE8 v\xE0 ng\u01B0\u1EDDi th\xE2n y\xEAu qu\xFD.`,
        actionStep: "H\xEDt th\u1EDF ch\u1EADm 3 nh\u1ECBp theo ph\u01B0\u01A1ng ph\xE1p 4-7-8, u\u1ED1ng m\u1ED9t ng\u1EE5m n\u01B0\u1EDBc v\xE0 nh\u1EAFc nh\u1EDF b\u1EA3n th\xE2n: 'T\xF4i x\u1EE9ng \u0111\xE1ng \u0111\u01B0\u1EE3c t\xF4n tr\u1ECDng b\u1EDFi ch\xEDnh m\xECnh.'",
        source: "fallback"
      });
    }
    const prompt = `H\u1ECDc sinh THPT c\xF3 suy ngh\u0129 ti\xEAu c\u1EF1c / t\u1EF1 ti v\u1EC1 c\u01A1 th\u1EC3 ho\u1EB7c b\u1ECB b\xECnh ph\u1EA9m:
"${thought}"

H\xE3y ph\xE2n t\xEDch theo li\u1EC7u ph\xE1p Nh\u1EADn th\u1EE9c - H\xE0nh vi (CBT) v\xE0 tr\u1EA3 l\u1EDDi theo c\u1EA5u tr\xFAc JSON sau:
{
  "trap": "T\xEAn b\u1EABy nh\u1EADn th\u1EE9c h\u1ECDc sinh \u0111ang m\u1EAFc ph\u1EA3i (v\xED d\u1EE5: Ph\xF3ng \u0111\u1EA1i khuy\u1EBFt \u0111i\u1EC3m, T\xE2m l\xFD \u0111en-ho\u1EB7c-tr\u1EAFng, Hi\u1EC7u \u1EE9ng \u0111\xE8n chi\u1EBFu Spotlight Effect, Suy di\u1EC5n ti\xEAu c\u1EF1c...)",
  "truth": "S\u1EF1 th\u1EADt kh\xE1ch quan gi\xFAp h\u1ECDc sinh nh\u1EADn ra gi\xE1 tr\u1ECB th\u1EF1c v\xE0 gi\u1EA3m b\u1EDBt t\u1EF1 ti (vi\u1EBFt \u1EA5m \xE1p, khoa h\u1ECDc, kho\u1EA3ng 2-3 c\xE2u)",
  "actionStep": "M\u1ED9t h\xE0nh \u0111\u1ED9ng t\xEDch c\u1EF1c nh\u1ECF c\u1EE5 th\u1EC3 m\xE0 h\u1ECDc sinh c\xF3 th\u1EC3 th\u1EF1c hi\u1EC7n ngay \u0111\u1EC3 chuy\u1EC3n h\xF3a c\u1EA3m x\xFAc"
}`;
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: PSYCHOLOGIST_SYSTEM_INSTRUCTION,
        responseMimeType: "application/json"
      }
    });
    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);
  } catch (error) {
    console.error("AI Reframe Error:", error);
    res.status(500).json({
      error: "Kh\xF4ng th\u1EC3 x\u1EED l\xFD t\xE1i \u0111\u1ECBnh h\xECnh nh\u1EADn th\u1EE9c.",
      details: error?.message
    });
  }
});
app.post("/api/ai/assessment-advice", async (req, res) => {
  try {
    const { pustinScore, cnvctScore, lttScore, pustinLabel, cnvctLabel, lttLabel } = req.body;
    const ai = getAIClient();
    if (!ai) {
      return res.json({
        advice: `D\u1EF1a tr\xEAn k\u1EBFt qu\u1EA3 t\u1EF1 \u0111\xE1nh gi\xE1 c\u1EE7a b\u1EA1n (M\u1EE9c \u0111\u1ED9 \u1EA3nh h\u01B0\u1EDFng b\xECnh ph\u1EA9m: ${pustinLabel}, M\u1EE9c \u0111\u1ED9 b\u1EA5t m\xE3n c\u01A1 th\u1EC3: ${cnvctLabel}, L\xF2ng t\u1EF1 tr\u1ECDng: ${lttLabel}): B\u1EA1n \u0111ang gi\u1EEF m\u1ED9t n\u1EC1n t\u1EA3ng c\u1EA3m x\xFAc kh\xE1 t\u1ED1t. H\xE3y ti\u1EBFp t\u1EE5c c\u1EE7ng c\u1ED1 s\u1EF1 t\u1EF1 tin b\u1EB1ng c\xE1ch ph\xE1t tri\u1EC3n s\u1EDF th\xEDch c\xE1 nh\xE2n v\xE0 kh\xF4ng \u0111\u1EC3 l\u1EDDi b\xECnh ph\u1EA9m c\u1EE7a ng\u01B0\u1EDDi kh\xE1c \u1EA3nh h\u01B0\u1EDFng \u0111\u1EBFn gi\xE1 tr\u1ECB c\u1EE7a m\xECnh.`,
        source: "fallback"
      });
    }
    const prompt = `H\u1ECDc sinh v\u1EEBa ho\xE0n th\xE0nh b\xE0i tr\u1EAFc nghi\u1EC7m t\xE2m l\xFD 3 tr\u1EE5 c\u1ED9t v\u1EDBi k\u1EBFt qu\u1EA3:
1. Tr\u1EA3i nghi\u1EC7m b\u1ECB b\xECnh ph\u1EA9m ngo\u1EA1i h\xECnh (PUSTIN): ${pustinScore}/5.0 (${pustinLabel})
2. B\u1EA5t m\xE3n h\xECnh \u1EA3nh c\u01A1 th\u1EC3 (CNVCT): ${cnvctScore}/5.0 (${cnvctLabel})
3. L\xF2ng t\u1EF1 tr\u1ECDng b\u1EA3n th\xE2n (LTT): ${lttScore}/5.0 (${lttLabel})

H\xE3y \u0111\u01B0a ra l\u1EDDi nh\u1EADn x\xE9t v\xE0 b\u1EA3n k\u1EBF ho\u1EA1ch ch\u0103m s\xF3c t\xE2m l\xFD c\xE1 nh\xE2n h\xF3a d\xE0nh ri\xEAng cho h\u1ECDc sinh n\xE0y. G\u1ED3m:
1. Nh\u1EADn x\xE9t t\u1ED5ng quan v\u1EC1 b\u1EE9c tranh t\xE2m l\xFD hi\u1EC7n t\u1EA1i c\u1EE7a em (\u0111\u1ED9ng vi\xEAn, kh\xEDch l\u1EC7).
2. 3 g\u1EE3i \xFD h\xE0nh \u0111\u1ED9ng thi\u1EBFt th\u1EF1c nh\u1EA5t em n\xEAn \u01B0u ti\xEAn l\xE0m trong tu\u1EA7n t\u1EDBi \u0111\u1EC3 n\xE2ng cao l\xF2ng t\u1EF1 tr\u1ECDng v\xE0 b\u1EA3o v\u1EC7 b\u1EA3n th\xE2n tr\u01B0\u1EDBc nh\u1EEFng b\xECnh ph\u1EA9m ngo\u1EA1i h\xECnh.`;
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: PSYCHOLOGIST_SYSTEM_INSTRUCTION,
        temperature: 0.7
      }
    });
    res.json({ advice: response.text });
  } catch (error) {
    console.error("AI Assessment Advice Error:", error);
    res.status(500).json({
      error: "Kh\xF4ng th\u1EC3 t\u1EA1o l\u1EDDi khuy\xEAn c\xE1 nh\xE2n h\xF3a.",
      details: error?.message
    });
  }
});
app.post("/api/ai/scenario-coach", async (req, res) => {
  try {
    const { userScenario } = req.body;
    if (!userScenario || typeof userScenario !== "string") {
      return res.status(400).json({ error: "T\xECnh hu\u1ED1ng kh\xF4ng h\u1EE3p l\u1EC7" });
    }
    const ai = getAIClient();
    if (!ai) {
      return res.json({
        coach: `Khi g\u1EB7p t\xECnh hu\u1ED1ng n\xE0y, gi\u1EA3i ph\xE1p t\u1ED1t nh\u1EA5t l\xE0 gi\u1EEF n\xE9t m\u1EB7t b\xECnh t\u0129nh, m\u1EAFt nh\xECn th\u1EB3ng v\xE0 tr\u1EA3 l\u1EDDi ng\u1EAFn g\u1ECDn: "M\u1ED7i ng\u01B0\u1EDDi c\xF3 m\u1ED9t n\xE9t ri\xEAng, m\xECnh c\u1EA3m th\u1EA5y tho\u1EA3i m\xE1i v\u1EDBi \u0111i\u1EC1u \u0111\xF3." Sau \u0111\xF3 nh\u1EB9 nh\xE0ng chuy\u1EC3n ch\u1EE7 \u0111\u1EC1 ho\u1EB7c r\u1EDDi kh\u1ECFi kh\xF4ng gian \u0111\xF3 \u0111\u1EC3 b\u1EA3o v\u1EC7 n\u0103ng l\u01B0\u1EE3ng c\u1EE7a m\xECnh.`,
        source: "fallback"
      });
    }
    const prompt = `H\u1ECDc sinh THPT chia s\u1EBB t\xECnh hu\u1ED1ng th\u1EF1c t\u1EBF em g\u1EB7p ph\u1EA3i:
"${userScenario}"

H\xE3y \u0111\xF3ng vai hu\u1EA5n luy\u1EC7n vi\xEAn k\u1EF9 n\u0103ng giao ti\u1EBFp h\u1ECDc \u0111\u01B0\u1EDDng v\xE0 h\u01B0\u1EDBng d\u1EABn em:
1. \u0110\xE1nh gi\xE1 nhanh t\xECnh hu\u1ED1ng: \xDD \u0111\u1ED3 c\u1EE7a ng\u01B0\u1EDDi n\xF3i l\xE0 g\xEC? Em c\xF3 l\u1ED7i g\xEC kh\xF4ng? (Kh\u1EB3ng \u0111\u1ECBnh em kh\xF4ng c\xF3 l\u1ED7i).
2. C\xE2u tho\u1EA1i \u0111\u1ED1i \u0111\xE1p g\u1EE3i \xFD chu\u1EA9n "Quy\u1EBFt \u0111o\xE1n & L\u1ECBch thi\u1EC7p" (Assertive response) em c\xF3 th\u1EC3 d\xF9ng ngay.
3. K\u1EBF ho\u1EA1ch b\u1EA3o v\u1EC7 t\xE2m l\xFD sau khi t\xECnh hu\u1ED1ng k\u1EBFt th\xFAc.`;
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: PSYCHOLOGIST_SYSTEM_INSTRUCTION,
        temperature: 0.7
      }
    });
    res.json({ coach: response.text });
  } catch (error) {
    console.error("AI Scenario Coach Error:", error);
    res.status(500).json({
      error: "Kh\xF4ng th\u1EC3 ph\xE2n t\xEDch t\xECnh hu\u1ED1ng l\xFAc n\xE0y.",
      details: error?.message
    });
  }
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
