import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getAIClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

const PSYCHOLOGIST_SYSTEM_INSTRUCTION = `Bạn là Chuyên gia Tâm lý Học đường AI thuộc ứng dụng "Cẩm Nang Hình Ảnh Cơ Thể & Lòng Tự Trọng" dành cho học sinh THPT (từ 15-18 tuổi).
Phong cách của bạn:
- Thấu cảm sâu sắc, ấm áp, bao dung và tôn trọng tuyệt đối cảm xúc của học sinh.
- Ngôn ngữ tự nhiên, hiện đại, gần gũi với lứa tuổi học trò (có thể xưng "Thầy/Cô/Chuyên gia" hoặc "Mình" và gọi người hỏi là "Bạn/Em").
- Tuyệt đối không phán xét, không đưa ra lời khuyên sáo rỗng hoặc khuyên can hời hợt kiểu "hãy cố lên", "đừng nghĩ thế nữa".
- Luôn dựa trên các nền tảng khoa học tâm lý:
  1. Body Neutrality (Tính trung dung cơ thể): Cơ thể là ngôi nhà quý giá giúp ta học tập, vui chơi, thở và sống — không phải món hàng trang trí để người khác định giá.
  2. Lòng tự trọng đa diện: Ngoại hình chỉ là một phần rất nhỏ. Giá trị con người được bồi đắp bởi trí tuệ, lòng nhân hậu, sự nỗ lực và cách ta đối xử với xung quanh.
  3. Kỹ năng ứng phó bình phẩm: Giữ bình tĩnh, đặt ranh giới quyết đoán (Assertive) hoặc chuyển hướng khéo léo; không công kích thù địch và cũng không im lặng cam chịu.
- Nếu người dùng chia sẻ những dấu hiệu nguy hiểm (tự hại, trầm cảm nặng, bi quan cực độ), hãy dịu dàng khuyên em liên hệ người lớn đáng tin cậy hoặc Tổng đài Quốc gia Bảo vệ Trẻ em 111 (miễn cước 24/7).`;

// 1. General Psychological Advice / Q&A
app.post("/api/ai/counselor", async (req, res) => {
  try {
    const { question, context } = req.body;
    if (!question || typeof question !== "string") {
      return res.status(400).json({ error: "Câu hỏi không hợp lệ" });
    }

    const ai = getAIClient();
    if (!ai) {
      // Graceful fallback response if API key is not yet set
      return res.json({
        advice: `Cảm ơn bạn đã tâm sự cùng chuyên gia tâm lý. Về vấn đề "${question}": Hãy nhớ rằng cơ thể của bạn đang trong giai đoạn phát triển tuổi dậy thì với nhiều thay đổi tự nhiên. Mọi lời chê bai từ người khác phản ánh sự thiếu tế nhị của họ, không định nghĩa giá trị con người bạn. Hãy hít thở sâu, tập trung vào những điều bạn làm tốt và bao dung hơn với chính mình bạn nhé!`,
        source: "fallback",
      });
    }

    const prompt = `Học sinh THPT gửi câu hỏi / nỗi niềm:
"${question}"
${context ? `Bối cảnh phụ trợ: ${context}` : ""}

Hãy đưa ra lời khuyên tâm lý chân thành, chi tiết và thực tế (chia thành 3 phần ngắn gọn: 1. Thấu cảm & Đón nhận cảm xúc; 2. Giải mã tâm lý; 3. Lời khuyên & Hành động cụ thể em có thể làm ngay).`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: PSYCHOLOGIST_SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    res.json({ advice: response.text || "Hiện tại chuyên gia chưa phản hồi được, bạn thử lại nhé!" });
  } catch (error: any) {
    console.error("AI Counselor Error:", error);
    res.status(500).json({
      error: "Không thể kết nối với chuyên gia AI lúc này.",
      details: error?.message,
    });
  }
});

// 2. Cognitive Reframing (CBT) for Negative Thoughts
app.post("/api/ai/reframe", async (req, res) => {
  try {
    const { thought } = req.body;
    if (!thought || typeof thought !== "string") {
      return res.status(400).json({ error: "Suy nghĩ không hợp lệ" });
    }

    const ai = getAIClient();
    if (!ai) {
      return res.json({
        trap: "Bẫy suy nghĩ tự phán xét & Phóng đại khuyết điểm (Spotlight Effect)",
        truth: `Ngoại hình chỉ là một phần rất nhỏ trong con người bạn. Suy nghĩ "${thought}" là cảm xúc tức thời, không phải là sự thật về giá trị bản thân. Bạn vẫn có nhiều tài năng, phẩm chất tốt đẹp mà bạn bè và người thân yêu quý.`,
        actionStep: "Hít thở chậm 3 nhịp theo phương pháp 4-7-8, uống một ngụm nước và nhắc nhở bản thân: 'Tôi xứng đáng được tôn trọng bởi chính mình.'",
        source: "fallback",
      });
    }

    const prompt = `Học sinh THPT có suy nghĩ tiêu cực / tự ti về cơ thể hoặc bị bình phẩm:
"${thought}"

Hãy phân tích theo liệu pháp Nhận thức - Hành vi (CBT) và trả lời theo cấu trúc JSON sau:
{
  "trap": "Tên bẫy nhận thức học sinh đang mắc phải (ví dụ: Phóng đại khuyết điểm, Tâm lý đen-hoặc-trắng, Hiệu ứng đèn chiếu Spotlight Effect, Suy diễn tiêu cực...)",
  "truth": "Sự thật khách quan giúp học sinh nhận ra giá trị thực và giảm bớt tự ti (viết ấm áp, khoa học, khoảng 2-3 câu)",
  "actionStep": "Một hành động tích cực nhỏ cụ thể mà học sinh có thể thực hiện ngay để chuyển hóa cảm xúc"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: PSYCHOLOGIST_SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);
  } catch (error: any) {
    console.error("AI Reframe Error:", error);
    res.status(500).json({
      error: "Không thể xử lý tái định hình nhận thức.",
      details: error?.message,
    });
  }
});

// 3. Personalized Assessment Advice
app.post("/api/ai/assessment-advice", async (req, res) => {
  try {
    const { pustinScore, cnvctScore, lttScore, pustinLabel, cnvctLabel, lttLabel } = req.body;

    const ai = getAIClient();
    if (!ai) {
      return res.json({
        advice: `Dựa trên kết quả tự đánh giá của bạn (Mức độ ảnh hưởng bình phẩm: ${pustinLabel}, Mức độ bất mãn cơ thể: ${cnvctLabel}, Lòng tự trọng: ${lttLabel}): Bạn đang giữ một nền tảng cảm xúc khá tốt. Hãy tiếp tục củng cố sự tự tin bằng cách phát triển sở thích cá nhân và không để lời bình phẩm của người khác ảnh hưởng đến giá trị của mình.`,
        source: "fallback",
      });
    }

    const prompt = `Học sinh vừa hoàn thành bài trắc nghiệm tâm lý 3 trụ cột với kết quả:
1. Trải nghiệm bị bình phẩm ngoại hình (PUSTIN): ${pustinScore}/5.0 (${pustinLabel})
2. Bất mãn hình ảnh cơ thể (CNVCT): ${cnvctScore}/5.0 (${cnvctLabel})
3. Lòng tự trọng bản thân (LTT): ${lttScore}/5.0 (${lttLabel})

Hãy đưa ra lời nhận xét và bản kế hoạch chăm sóc tâm lý cá nhân hóa dành riêng cho học sinh này. Gồm:
1. Nhận xét tổng quan về bức tranh tâm lý hiện tại của em (động viên, khích lệ).
2. 3 gợi ý hành động thiết thực nhất em nên ưu tiên làm trong tuần tới để nâng cao lòng tự trọng và bảo vệ bản thân trước những bình phẩm ngoại hình.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: PSYCHOLOGIST_SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    res.json({ advice: response.text });
  } catch (error: any) {
    console.error("AI Assessment Advice Error:", error);
    res.status(500).json({
      error: "Không thể tạo lời khuyên cá nhân hóa.",
      details: error?.message,
    });
  }
});

// 4. Scenario Coach
app.post("/api/ai/scenario-coach", async (req, res) => {
  try {
    const { userScenario } = req.body;
    if (!userScenario || typeof userScenario !== "string") {
      return res.status(400).json({ error: "Tình huống không hợp lệ" });
    }

    const ai = getAIClient();
    if (!ai) {
      return res.json({
        coach: `Khi gặp tình huống này, giải pháp tốt nhất là giữ nét mặt bình tĩnh, mắt nhìn thẳng và trả lời ngắn gọn: "Mỗi người có một nét riêng, mình cảm thấy thoải mái với điều đó." Sau đó nhẹ nhàng chuyển chủ đề hoặc rời khỏi không gian đó để bảo vệ năng lượng của mình.`,
        source: "fallback",
      });
    }

    const prompt = `Học sinh THPT chia sẻ tình huống thực tế em gặp phải:
"${userScenario}"

Hãy đóng vai huấn luyện viên kỹ năng giao tiếp học đường và hướng dẫn em:
1. Đánh giá nhanh tình huống: Ý đồ của người nói là gì? Em có lỗi gì không? (Khẳng định em không có lỗi).
2. Câu thoại đối đáp gợi ý chuẩn "Quyết đoán & Lịch thiệp" (Assertive response) em có thể dùng ngay.
3. Kế hoạch bảo vệ tâm lý sau khi tình huống kết thúc.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: PSYCHOLOGIST_SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    res.json({ coach: response.text });
  } catch (error: any) {
    console.error("AI Scenario Coach Error:", error);
    res.status(500).json({
      error: "Không thể phân tích tình huống lúc này.",
      details: error?.message,
    });
  }
});

// Start server with Vite middleware in dev or static serving in prod
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
